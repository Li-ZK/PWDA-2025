import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='Openset-DA')
    parser.add_argument('--log_name', type=str, default='PWDA')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--train_num', type=int, default=180)
    parser.add_argument('--few_train_num', type=int, default=140)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--batch', type=int, default=32)
    parser.add_argument('--patch', type=int, default=15)
    parser.add_argument('--source_dataset', choices=['Houston13_7gt', 'PaviaU_7gt'], default= 'PaviaU_7gt')
    parser.add_argument('--source_known_classes', type=list, default= [1, 2, 3, 4, 5, 6, 7])
    parser.add_argument('--target_dataset', choices=['Houston18_7gt', 'PaviaC_OS'], default='PaviaC_OS')
    parser.add_argument('--target_known_classes', type=list, default= [1, 2, 3, 4, 5, 6, 7])
    parser.add_argument('--target_unknown_classes', type=list, default=[9])
    parser.add_argument('--draw', type=str, default='True')

    parser.add_argument('--epochs', type=int, default=20, metavar='N', help='number of epochs to train (default: 200)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR', help='learning rate (default: 0.001)')
    parser.add_argument('--momentum', default=0.9, type=float, metavar='M', help='momentum')
    parser.add_argument('--weight-decay', '--wd', default=1e-4, type=float, metavar='W', help='weight decay (default: 1e-4)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N', help='how many batches to wait before logging training status')
    parser.add_argument('--bp-th', type=float, default=0.4, metavar='TH', help='threshold (default: 0.5)')
    parser.add_argument('--bp-grl', type=float, default=0.5, metavar='TH', help='grl adversarial weight (default: 0.5)')
    parser.add_argument('--warm_up_epoch', default=15, type=int, help='source-domain pretraining')
    parser.add_argument('--topk', default=3, type=int, help='select potential unk regions')
    parser.add_argument('--mining_th', default=1.0, type=float, metavar='TH', help='unk label')
    parser.add_argument('--mining_grl', type=float, default=0.2, metavar='TH', help='grad scaler (default: 0.2)')
    parser.add_argument('--all-layer-adv', action='store_true', default=False, help='align all layers')
    parser.add_argument('--adv-grl', type=float, default=0.1, metavar='TH', help='grl adversarial weight (default: 0.1)')
    parser.add_argument('--seed_list', type=list, default=[1, 2, 3, 4, 5, 6, 7])

    args = parser.parse_args()

    if args.source_dataset == 'Houston13_7gt' :

        args.source_known_classes = [1, 2, 3, 4, 5, 6]
        args.target_known_classes = [1, 2, 3, 4, 5, 6]
        args.target_unknown_classes = [7]
        args.seed_list = [15, 23, 27, 31, 40, 52, 61, 115, 171, 175]
    elif args.source_dataset == 'PaviaU_7gt' :

        args.source_known_classes = [1, 2, 3, 4, 5, 6, 7]
        args.target_known_classes = [1, 2, 3, 4, 5, 6, 7]
        args.target_unknown_classes = [9]
        args.seed_list = [1, 2, 4, 11, 15, 25, 41, 47, 55 ,80]


    return args