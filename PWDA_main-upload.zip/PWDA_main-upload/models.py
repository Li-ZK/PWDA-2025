import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.decomposition import PCA
from torchvision import models

class RevGrad(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input_, alpha_):
        ctx.save_for_backward(input_, alpha_)
        output = input_
        return output

    @staticmethod
    def backward(ctx, grad_output):  # pragma: no cover
        grad_input = None
        _, alpha_ = ctx.saved_tensors
        if ctx.needs_input_grad[0]:
            grad_input = -grad_output * alpha_
        return grad_input, None

revgrad = RevGrad.apply

class RevGrad(nn.Module):
    def __init__(self, alpha=1., *args, **kwargs):
        """
        A gradient reversal layer.

        This layer has no parameters, and simply reverses the gradient
        in the backward pass.
        """
        super().__init__(*args, **kwargs)
        self._alpha = torch.tensor(alpha, requires_grad=False)
    def forward(self, input_):
        return revgrad(input_, self._alpha)
def grad_reverse(x, lambd=1.0):
    return RevGrad(lambd)(x)


class Net(nn.Module):
    def __init__(self, args, in_channels, unknown_num_classes):
        super(Net, self).__init__()

        # self.generator = ResBase(in_channels)
        self.generator = ResBaseNonePool(in_channels)
        self.classifier = Classifier(unknown_num_classes, unit_size=1024)
 
        dim = 1024 if args.all_layer_adv else 3072
        self.adv_k = AdversarialNetwork(dim)
        self.adv_unk = AdversarialNetwork(dim)

    def forward(self, x, constant=1, adaption=False):
        rois = self.generator(x)
        x = self.classifier(rois, constant, adaption)
        return  x

class ResBase(nn.Module):
    def __init__(self, in_channels):
        super(ResBase, self).__init__()
        self.conv_in = nn.Conv2d(in_channels, 3, (3, 3), 1, 1)
        self.CNN = models.resnet50(pretrained=False)
        self.average_pooling = nn.AdaptiveAvgPool2d((1, 1))
        modules = list(self.CNN.children())[:-2]
        self.CNN = nn.Sequential(*modules)
    def forward(self, imgs):
        imgs = self.conv_in(imgs)
        rois = self.CNN(imgs)
        return rois

class ResBaseNonePool(nn.Module):
    def __init__(self, in_channels):
        super(ResBaseNonePool, self).__init__()
        self.conv_in = nn.Sequential(
            nn.Conv2d(in_channels, 3, (3, 3), 1, 1),
            nn.BatchNorm2d(3),
            nn.ReLU()
        )
        self.feature_dim = in_channels
        model_resnet = models.resnet50(pretrained=True)

        for i, j in model_resnet.named_modules():
            if isinstance(j, nn.Conv2d):
                j.stride = (1, 1)

        self.conv1 = model_resnet.conv1
        self.bn1 = model_resnet.bn1
        self.relu = model_resnet.relu
        # self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        # self.bn1 = nn.BatchNorm2d(64, affine=True, track_running_stats=True)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = model_resnet.maxpool
        self.layer1 = model_resnet.layer1
        self.layer2 = model_resnet.layer2
        self.layer3 = model_resnet.layer3
        self.layer4 = model_resnet.layer4
        self.avgpool = model_resnet.avgpool
        self.__in_features = model_resnet.fc.in_features

        self.convf1 = nn.Conv3d(1, 64, kernel_size=(7, 1, 1), stride=(2, 1, 1), bias=True)
        self.bnf1 = nn.BatchNorm3d(64)
        self.activation1 = nn.ReLU()

        # Residual block 1
        self.convf2 = nn.Conv3d(64, 64, kernel_size=(7, 1, 1), stride=1, padding=(3, 0, 0),
                               bias=True)  # padding_mode='replicate',
        self.bnf2 = nn.BatchNorm3d(64)
        self.activation2 = nn.ReLU()
        self.convf3 = nn.Conv3d(64, 64, kernel_size=(7, 1, 1), stride=1, padding=(3, 0, 0),
                               bias=True)  # padding_mode='replicate',
        self.bnf3 = nn.BatchNorm3d(64)
        self.activation3 = nn.ReLU()
        # Finish
        self.convf4 = nn.Conv3d(64, 512, kernel_size=(7, 1, 1), stride=1, padding=(3, 0, 0),
                               bias=True)  # padding_mode='replicate',
        self.bnf4 = nn.BatchNorm3d(512)
        self.activation4 = nn.ReLU()
        # Convolution Layer 2 kernel_size = (1, 1, (self.feature_dim - 6) // 2), output channels = 128
        self.convf5 = nn.Conv3d(512, 1024, kernel_size=(((self.feature_dim - 7) // 2 + 1), 1, 1), bias=True)
        self.bnf5 = nn.BatchNorm3d(1024)
        self.activation5 = nn.ReLU()


    def forward(self, x):

        x2 = self.conv_in(x)
        x2 = self.conv1(x2)
        x2 = self.bn1(x2)
        x2 = self.relu(x2)
        # x = self.maxpool(x)
        x2 = self.layer1(x2)
        x2 = self.layer2(x2)
        x2 = self.layer3(x2)
        x2= self.layer4(x2)

        x1 = x.unsqueeze(1)  # (64,1,100,9,9)
        # Convolution layer 1
        x1 = self.convf1(x1)
        x1 = self.activation1(self.bnf1(x1))
        # Residual layer 1
        residual = x1
        x1 = self.convf2(x1)
        x1 = self.activation2(self.bnf2(x1))
        x1 = self.convf3(x1)
        x1 = residual + x1  # (32,24,21,7,7)
        x1 = self.activation3(self.bnf3(x1))

        # Convolution layer to combine rest
        x1 = self.convf4(x1)  # (32,128,1,7,7)
        x1 = self.activation4(self.bnf4(x1))

        x1 = self.convf5(x1)  # (32,128,1,7,7)
        x1 = self.activation5(self.bnf5(x1))

        x1 = x1.reshape(x1.size(0), x1.size(1), x1.size(3), x1.size(4))


        # x = self.avgpool(x)
        # x = x.view(x.size(0), -1)
        x = torch.cat((x1, x2), 1)
        return x

class Classifier(nn.Module):
    def __init__(self, num_classes, unit_size=100):
        super(Classifier, self).__init__()
        self.linear1 = nn.Linear(3072, unit_size)
        self.bn1 = nn.BatchNorm1d(unit_size, affine=True, track_running_stats=True)
        self.linear2 = nn.Linear(unit_size, unit_size)
        self.bn2 = nn.BatchNorm1d(unit_size, affine=True, track_running_stats=True)
        self.classifier = nn.Linear(unit_size, num_classes)
        self.drop = nn.Dropout(p=0.3)
        self.average_pooling = nn.AdaptiveAvgPool2d((1, 1))

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


    def forward(self, rois, constant=1, adaption=False, pooling=True, return_feat=False):

        if pooling:
            rois = self.average_pooling(rois).view(rois.size(0), -1)

        x = self.drop(F.relu(self.bn1(self.linear1(rois))))
        x = self.drop(F.relu(self.bn2(self.linear2(x))))

        # grl or grad scaling
        x_rev = grad_reverse(x, constant) if adaption else x
        logits = self.classifier(x_rev)

        if return_feat:
            return logits, x
        else:
            return logits

class AdversarialNetwork(nn.Module):
    def __init__(self, in_feature):
        super(AdversarialNetwork, self).__init__()

        self.average_pooling = nn.AdaptiveAvgPool2d((1, 1))
        self.main1 = nn.Sequential(
            nn.Linear(in_feature, 1024),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True,),
            nn.Linear(1024, 1024),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 1),
            nn.Sigmoid()
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, constant=0.05):
        x = grad_reverse(x, constant)
        for module in self.main1.children():
            x = module(x)
        return x.view(-1)

def kaiming_init(m):
    if isinstance(m, (nn.Linear, nn.Conv2d)):
        torch.nn.init.kaiming_normal(m.weight)
        if m.bias is not None:
            m.bias.data.fill_(0)
    elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d)):
        m.weight.data.fill_(1)
        if m.bias is not None:
            m.bias.data.fill_(0)
