from utils import *
import torch
import torch.nn as nn
import torch.nn.functional as F
import models

from config import parse_args
from utils97.dataLoader import getDataLoader
from utils97.utils import getDatasetInfo, seed_torch, getDevice
from utils97.logger import saveJSONFile
from utils97.meter import computeOpensetDomainResult

def PAWL(rois, targets):
    unk_pixel_list = []
    k_pixel_list = []
    loss_mining_dict = {}
    bs, c, h, w = rois.size()
    p_xk_x = 1.0

    for idx, roi in enumerate(rois):
        roi_label = targets[idx]  # bs x 1 (0-24)
        roi_flatten = roi.view(c, -1).permute(1, 0)

        model.classifier.apply(fix_bn)
        # constant > 0 is grl
        pixel_logits = model.classifier(roi_flatten, adaption=True, constant=-1 * args.mining_grl, pooling=False)
        pixel_scores = pixel_logits.softmax(-1)
        model.classifier.apply(enable_bn)

        sorted_value, sorted_index = pixel_scores[:, :-1].sort(-1, descending=True)
        k_mask = (sorted_index[:, :1] == roi_label).sum(-1).bool()
        unk_mask = ~((sorted_index[:, :args.topk] == roi_label).sum(-1).bool())

        if k_mask.any() and unk_mask.any() and k_mask.sum() > unk_mask.sum():
            unk_pixels = pixel_logits[unk_mask]
            k_pixels = pixel_logits[k_mask]
            unk_pixel_list.append(unk_pixels)
            k_pixel_list.append(k_pixels)

    if len(unk_pixel_list) > 1:

        num_lk = len(torch.cat(k_pixel_list))
        num_pu = len(torch.cat(unk_pixel_list))

        p_xu_x = num_pu / (num_pu + num_lk)
        p_xk_x = num_lk / (num_pu + num_lk)

        mined_scores = torch.cat(unk_pixel_list).softmax(-1)[:, -1]
        loss_mining_unk = p_xu_x * criterion_bce(mined_scores, torch.tensor([args.mining_th] * len(mined_scores)).to(device))
        loss_mining_dict.update(loss_mining_s=loss_mining_unk)
    return loss_mining_dict, p_xk_x

def DDA (rois, all_layers=False, domain='source'):
    domain_label = 1.0 if domain == 'source' else 0.0

    bs, c, h, w = rois.size()
    rois_flatten = rois.permute(0, 2, 3, 1).contiguous().view(-1, c)  # bs, h, w ,c

    model.classifier.apply(fix_bn)
    if not all_layers:
        with torch.no_grad():
            scores = model.classifier(rois_flatten, pooling=False).softmax(-1).detach()
    else:
        scores, rois_flatten = model.classifier(rois_flatten, pooling=False, return_feat=True)
        scores = scores.softmax(-1).detach()

    model.classifier.apply(enable_bn)

    target = torch.full((rois_flatten.size(0),),
                        domain_label,
                        dtype=torch.float,
                        device=rois_flatten.device)

    weight_unk = scores[:, -1]
    weight_k = scores[:, :-1].sum(-1)

    adv_k = model.adv_k(rois_flatten, args.adv_grl)
    adv_unk = model.adv_unk(rois_flatten, args.adv_grl)

    loss_adv_k = (criterion_bce_red(adv_k, target) * weight_k).mean()
    loss_adv_unk = (criterion_bce_red(adv_unk, target) * weight_unk).mean()

    return dict(loss_adv_k=loss_adv_k, loss_adv_unk=loss_adv_unk)

def train(epoch):
    model.train()
    iter_source = iter(source_train_loader)
    iter_target = iter(target_train_loader)
    num_iter = len(source_train_loader)
    for batch_idx in range(num_iter):
        data_s, target_s = next(iter_source)
        data_t, target_t = next(iter_target)

        data_s, target_s = data_s.to(device), target_s.long().to(device)
        data_t, target_t = data_t.to(device), target_t.long().to(device)

        loss_dict_s = {}
        loss_dict_t = {}

        # source domain 
        rois = model.generator(data_s)
        output_s = model.classifier(rois)
        loss_cls_s = criterion_ce(output_s, target_s)
        loss_dict_s.update(loss_cls_s=loss_cls_s)

        loss_mining_s, p_xk_x = PAWL(rois, target_s)

        loss_dict_s.update(loss_mining_s)
        loss_dict_s.update(loss_cls_s =loss_cls_s * p_xk_x)

        loss_align_s = DDA(rois, all_layers=args.all_layer_adv, domain='source')
        loss_dict_s.update(loss_align_s)

        loss_s = sum(loss for loss in loss_dict_s.values())
        loss_s.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=4.0, norm_type=2.0)

        opts.step()
        opts.zero_grad()

        # target domain
        rois = model.generator(data_t)
        output_t = model.classifier(rois, constant=args.bp_grl, adaption=True)
        score_unk = output_t.softmax(-1)[:, -1]
        loss_bp_t = criterion_bce(score_unk, torch.tensor([args.bp_th] * len(score_unk)).to(device))
        loss_dict_t.update(loss_bp_t=loss_bp_t)

        loss_align_t = DDA(rois, all_layers=args.all_layer_adv, domain='target')
        loss_dict_t.update(loss_align_t)

        loss_t = sum(loss for loss in loss_dict_t.values())
        loss_t.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=4.0, norm_type=2.0)

        opts.step()
        opts.zero_grad()

        if batch_idx % args.log_interval == 0:
            print(
                '[Epoch: {} ({:.0f}%)] [Loss_s: {:.3f}, Loss_t: {:.3f}], [lr:{:.4f}] {}'.format(
                    epoch,
                    100. * batch_idx / num_iter,
                    loss_s.item(),
                    loss_t.item(),
                    opts.param_groups[0]['lr'],
                    {**process_dict(loss_dict_s), **process_dict(loss_dict_t)}
                )
            )

def warm_up_train(epoch):
    model.train()
    iter_source = iter(source_train_loader)
    iter_target = iter(target_train_loader)
    num_iter = len(source_train_loader)
    for batch_idx in range(num_iter):
        data_s, target_s = next(iter_source)
        data_t, target_t = next(iter_target)

        data_s, target_s = data_s.to(device), target_s.long().to(device)
        data_t, target_t = data_t.to(device), target_t.long().to(device)

        loss_dict_s = {}
        rois = model.generator(data_s)
        output_s = model.classifier(rois)

        loss_cls_s = criterion_ce(output_s, target_s)
        loss_dict_s.update(loss_cls_s=loss_cls_s)

        loss_s = sum(loss for loss in loss_dict_s.values())
        loss_s.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=4.0, norm_type=2.0)
        opts.step()
        opts.zero_grad()

        rois = model.generator(data_t)
        output_t = model.classifier(rois, constant=args.bp_grl, adaption=True)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=4.0, norm_type=2.0)
        opts.step()
        opts.zero_grad()

        if batch_idx % args.log_interval == 0:
            print(
                '[Warm Up: Epoch: {} ({:.0f}%)] [Loss_s: {:.3f}], [lr:{:.4f}] {}'.format(
                    epoch,
                    100. * batch_idx / num_iter,
                    loss_s.item(),
                    opts.param_groups[0]['lr'],
                    {**process_dict(loss_dict_s)}
                )
            )

def test():
    model.eval()
    pred_y = []
    true_y = []

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(test_loader):
            data, target = data.to(device), target.to(device).long()
            rois = model.generator(data)
            output = model.classifier(rois).softmax(-1)
            pred = output.argmax(-1)

            pred_y.extend(pred.tolist())
            true_y.extend(target.tolist())

    save_dict = computeOpensetDomainResult(pred_y, true_y, len(args.source_known_classes))
    print(save_dict)

    return save_dict

def draw():
    model.eval()
    prediction_list = []
    with torch.no_grad():
        for data in data_loader['target']['all']:
            data = data.to(device)
            rois = model.generator(data)
            output = model.classifier(rois).softmax(-1)
            pred = output.argmax(-1)

            prediction_list.append(pred.cpu())
    
    from utils97.draw import drawPredictionMap

    drawPredictionMap(prediction_list, f'{args.log_name} {args.target_dataset}', target_info, args.target_known_classes, args.target_unknown_classes, False)

if __name__ == '__main__':

            args = parse_args()
            for seed in args.seed_list:
                args.seed = seed
                seed_torch(args.seed)
                #seed_torch(args.seed)
                device = getDevice(args.device)
                source_info = getDatasetInfo(args.source_dataset)
                target_info = getDatasetInfo(args.target_dataset)
                data_loader: dict = getDataLoader(args,source_info, target_info)

                source_train_loader = data_loader['source']['train']
                target_train_loader = data_loader['target']['train']
                test_loader = data_loader['target']['test']

                model = models.Net(args, source_info.bands_num, len(args.source_known_classes) + 1).to(device)
                opts = torch.optim.SGD(model.parameters(), args.lr,
                                    momentum=args.momentum,
                                    weight_decay=args.weight_decay,
                                    nesterov=True)
                criterion_bce = nn.BCELoss()
                criterion_bce_red = nn.BCELoss(reduction='none')
                criterion_ce = nn.CrossEntropyLoss()


                for epoch in range(1, args.warm_up_epoch + 1):
                    warm_up_train(epoch)

                for epoch in range(1, args.epochs + 1):
                    train(epoch)

                save_dict = test()

                saveJSONFile(f'logs/{args.log_name}/{args.log_name} {args.source_dataset}-{args.target_dataset} seed={args.seed}.json', save_dict)

                if args.draw == 'True':
                    draw()