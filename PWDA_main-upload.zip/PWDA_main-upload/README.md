This is a code demo for the paper "An Open-Set Domain Adaptation Framework for Hyperspectral Image Classification with Pixel-Aware Weighting and Decoupled Alignment". IEEE GEOSCIENCE AND REMOTE SENSING LETTERS, GRSL-02774-2024.

[1]Zhaokui Li,  Mingtai Qi, Yan Wang, Xuewei Gong, Cuiwei Liu, and Jinjun Wang “An Open-Set Domain Adaptation Framework for Hyperspectral Image Classification with Pixel-Aware Weighting and Decoupled Alignment,”IEEE GEOSCIENCE AND REMOTE SENSING LETTERS, GRSL-02774-2024.


## Requirements

python = 3.7.15

torchmetrics = 0.10.3



## Usage:

main.py
